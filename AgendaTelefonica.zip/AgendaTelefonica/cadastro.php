<?php
    include_once('conexao.php');
     $nome = $_POST['nome'];
     $email = $_POST['email'];
     $numero = $_POST['num'];

     $result_agenda = "INSERT INTO agenda (nomContato,telContato,emailContato) VALUES ('$nome','$email','$numero')";
     $resultado_agenda = mysqli_query($conn,$result_agenda);
?>