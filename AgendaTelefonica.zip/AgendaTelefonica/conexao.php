<?php
    $servidor = "localhost";
    $usuario = "root";
    $senha= "";
    $dbname= "agenda";

    //Cria a conexão
    $conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>